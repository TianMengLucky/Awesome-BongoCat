Skin Creator: 宇痕冫

This model may be used for personal use and non-profit livestreaming. Reselling is strictly prohibited.

This desktop pet skin is provided as a free trial version and is not the complete version.

If you like this skin and would like to experience the complete version, please consider supporting the author to get access to it!

---

皮肤作者：宇痕冫

本模型可用于个人使用及非盈利直播，禁止二次售卖。

此款桌宠皮肤为免费体验版，内容并非完整版本。

如果喜欢这款皮肤，并希望体验完整内容，欢迎支持作者获取完整版！
